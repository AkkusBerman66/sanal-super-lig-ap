import { useState } from "react";

const initialTeams = [
  "Galatasaray", "Fenerbahçe", "Beşiktaş", "Trabzonspor",
  "Başakşehir", "Adana Demirspor", "Konyaspor", "Sivasspor",
  "Kayserispor", "Antalyaspor", "Alanyaspor", "Gaziantep FK",
  "Hatayspor", "Çaykur Rizespor", "Samsunspor", "Pendikspor",
  "İstanbulspor", "Karagümrük", "Kasımpaşa", "MKE Ankaragücü"
];

export default function SuperLigApp() {
  const [matches, setMatches] = useState([]);
  const [home, setHome] = useState("");
  const [away, setAway] = useState("");
  const [score, setScore] = useState("");

  const addMatch = () => {
    if (home && away && score && home !== away) {
      setMatches([...matches, { home, away, score }]);
      setHome("");
      setAway("");
      setScore("");
    }
  };

  return (
    <div style={{ padding: '1rem', maxWidth: '600px', margin: 'auto' }}>
      <h1 style={{ fontSize: '24px', fontWeight: 'bold' }}>Sanal Süper Lig Uygulaması</h1>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '0.5rem', margin: '1rem 0' }}>
        <input
          placeholder="Ev Sahibi Takım"
          list="teams"
          value={home}
          onChange={(e) => setHome(e.target.value)}
        />
        <input
          placeholder="Deplasman Takım"
          list="teams"
          value={away}
          onChange={(e) => setAway(e.target.value)}
        />
        <input
          placeholder="Skor (Örnek: 2-1)"
          value={score}
          onChange={(e) => setScore(e.target.value)}
        />
      </div>

      <button onClick={addMatch}>Maçı Kaydet</button>

      <datalist id="teams">
        {initialTeams.map((team) => (
          <option key={team} value={team} />
        ))}
      </datalist>

      <div style={{ marginTop: '1rem' }}>
        <h2 style={{ fontSize: '18px', fontWeight: 'bold' }}>Kayıtlı Maçlar</h2>
        {matches.map((match, index) => (
          <div key={index} style={{ marginTop: '0.25rem', padding: '0.5rem', border: '1px solid #ccc' }}>
            {match.home} {match.score} {match.away}
          </div>
        ))}
      </div>
    </div>
  );
}